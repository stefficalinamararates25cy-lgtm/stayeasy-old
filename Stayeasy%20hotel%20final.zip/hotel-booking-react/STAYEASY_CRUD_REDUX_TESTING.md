# StayEasy Hotel Booking — CRUD and Redux testing

This update keeps the existing hotel booking screens and adds a **CRUD & Redux** page for testing.

## Run locally
1. Open this folder in a terminal.
2. Run `npm install`.
3. Run `npm run dev` and open the URL Vite prints.
4. Click **CRUD & Redux** in the top navigation.

## Test REST API CRUD
- Click **Load (GET)** to request `https://jsonplaceholder.typicode.com/posts?_limit=5`.
- Click **Create (POST)** to send a demo post.
- Click **Update (PUT)** on a listed item.
- Click **Delete** on a listed item.
- Open browser DevTools (`F12`) → **Network** → **Fetch/XHR** to inspect requests and responses.
- JSONPlaceholder is a demo API: writes return simulated responses and are not permanently stored on its server.

## Test Redux
- Click **Run Redux Actions** to dispatch booking actions.
- The Redux middleware logs actions in Console and persists state in `localStorage` under `hotelBooking`.
- Click **Clear Redux Booking** to reset the Redux booking form state.

## Test storage
- Click **Test localStorage + sessionStorage**.
- Inspect DevTools → **Application** → **Local Storage** for `stayEasyCrudTest` and `hotelBooking`.
- Inspect **Session Storage** for `stayEasySessionTest` and `accessToken` after login.

## Existing tests/build
Run `npm test` and `npm run build` locally before deployment. The environment used to prepare this ZIP could not finish installing npm dependencies, so fresh test/build results are not claimed here.
