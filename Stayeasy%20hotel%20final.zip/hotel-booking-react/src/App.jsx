
import { lazy, Suspense, useMemo, useState } from "react";
import Loading from "./Loading.jsx";
const Login = lazy(() => import("./pages/LoginForm.jsx"));
import "./index.css";
import CrudReduxTools from "./pages/CrudReduxTools.jsx";

const hotelData = [
  {
    id: 1,
    name: "Grand Palace Hotel",
    location: "Chennai",
    rating: 5,
    price: 5000,
    amenities: ["WiFi", "Pool", "Restaurant"],
    image:
      "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=900",
    description: "Luxury stay with elegant rooms and premium facilities.",
  },
  {
    id: 2,
    name: "Green Valley Resort",
    location: "Ooty",
    rating: 4,
    price: 3500,
    amenities: ["WiFi", "Restaurant", "Parking"],
    image:
      "https://images.unsplash.com/photo-1445019980597-93fa8acb246c?w=900",
    description: "A peaceful resort surrounded by beautiful green hills.",
  },
  {
    id: 3,
    name: "City Comfort Inn",
    location: "Coimbatore",
    rating: 3,
    price: 1800,
    amenities: ["WiFi", "Parking"],
    image:
      "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=900",
    description: "A comfortable and affordable stay for every traveller.",
  },
  {
    id: 4,
    name: "Marina Beach Hotel",
    location: "Chennai",
    rating: 4,
    price: 3200,
    amenities: ["WiFi", "Pool", "Parking"],
    image:
      "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=900",
    description: "Enjoy a stylish stay near Chennai's coastal attractions.",
  },
  {
    id: 5,
    name: "Mountain View Stay",
    location: "Kodaikanal",
    rating: 5,
    price: 6000,
    amenities: ["WiFi", "Restaurant", "Parking"],
    image:
      "https://images.unsplash.com/photo-1518732714860-b62714ce0c59?w=900",
    description: "Relax in a premium mountain retreat with scenic views.",
  },
];

const roomOptions = [
  { name: "Standard", multiplier: 1 },
  { name: "Deluxe", multiplier: 1.3 },
  { name: "Suite", multiplier: 1.8 },
];

function Header({ page, onNavigate, user, onLogout }) {
  return (
    <header className="header">
      <button aria-label="StayEasy home" className="brand" onClick={() => onNavigate("home")}>
        StayEasy
      </button>
      <nav>
        <button onClick={() => onNavigate("home")}>Home</button>
        <button onClick={() => onNavigate("hotels")}>Hotels</button>
        <button onClick={() => onNavigate("tools")}>CRUD & Redux</button>
        <button onClick={() => onNavigate("bookings")}>My Bookings</button>
        {!user ? (
          <button onClick={() => onNavigate("login")}>Login</button>
        ) : (
          <button onClick={onLogout}>Logout</button>
        )}
      </nav>
    </header>
  );
}

function SearchBar({ search, setSearch, checkIn, setCheckIn, checkOut, setCheckOut }) {
  return (
    <div className="search-bar">
      <label>
        Destination
        <input
          aria-label="Search destination or hotel"
          placeholder="Enter city or hotel"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </label>
      <label>
        Check-in
        <input
          type="date"
          value={checkIn}
          onChange={(e) => setCheckIn(e.target.value)}
        />
      </label>
      <label>
        Check-out
        <input
          type="date"
          min={checkIn || undefined}
          value={checkOut}
          onChange={(e) => setCheckOut(e.target.value)}
        />
      </label>
    </div>
  );
}

function FilterPanel({ maxPrice, setMaxPrice, rating, setRating, amenities, setAmenities }) {
  const choices = ["WiFi", "Pool", "Restaurant", "Parking"];

  function toggleAmenity(item) {
    setAmenities((previous) =>
      previous.includes(item)
        ? previous.filter((amenity) => amenity !== item)
        : [...previous, item]
    );
  }

  return (
    <aside className="filters">
      <h3>Filter Hotels</h3>
      <label>
        Maximum price: ₹{maxPrice}
        <input
          type="range"
          min="1000"
          max="8000"
          step="500"
          value={maxPrice}
          onChange={(e) => setMaxPrice(Number(e.target.value))}
        />
      </label>

      <label>
        Star rating
        <select value={rating} onChange={(e) => setRating(Number(e.target.value))}>
          <option value={0}>All ratings</option>
          <option value={3}>3 stars and above</option>
          <option value={4}>4 stars and above</option>
          <option value={5}>5 stars only</option>
        </select>
      </label>

      <h4>Amenities</h4>
      {choices.map((item) => (
        <label className="check-label" key={item}>
          <input
            type="checkbox"
            checked={amenities.includes(item)}
            onChange={() => toggleAmenity(item)}
          />
          {item}
        </label>
      ))}
    </aside>
  );
}

function HotelCard({ hotel, onSelect }) {
  return (
    <article className="hotel-card">
      <img src={hotel.image} alt={hotel.name} loading="lazy" decoding="async" />
      <div className="hotel-card-content">
        <p className="stars">{"★".repeat(hotel.rating)}{"☆".repeat(5 - hotel.rating)}</p>
        <h3>{hotel.name}</h3>
        <p>{hotel.location}</p>
        <p>{hotel.amenities.join(" · ")}</p>
        <div className="hotel-card-bottom">
          <strong>₹{hotel.price.toLocaleString("en-IN")} <small>/ night</small></strong>
          <button onClick={() => onSelect(hotel)}>View Details</button>
        </div>
      </div>
    </article>
  );
}

function HotelList({ hotels, onSelect }) {
  return (
    <div className="hotel-grid">
      {hotels.map((hotel) => (
        <HotelCard key={hotel.id} hotel={hotel} onSelect={onSelect} />
      ))}
      {hotels.length === 0 && (
        <p className="empty">No hotels match your filters. Try changing them.</p>
      )}
    </div>
  );
}

function HotelDetail({ hotel, onBack, onSelectRoom }) {
  return (
    <section className="detail-card">
      <img className="detail-image" src={hotel.image} alt={hotel.name} loading="lazy" decoding="async" />
      <p className="stars">{"★".repeat(hotel.rating)}{"☆".repeat(5 - hotel.rating)}</p>
      <h2>{hotel.name}</h2>
      <p>{hotel.location}</p>
      <p>{hotel.description}</p>
      <p><strong>Amenities:</strong> {hotel.amenities.join(", ")}</p>
      <h3>From ₹{hotel.price.toLocaleString("en-IN")} per night</h3>
      <div className="actions">
        <button className="secondary" onClick={onBack}>Back to Hotels</button>
        <button onClick={onSelectRoom}>Select Room</button>
      </div>
    </section>
  );
}

function RoomSelection({ hotel, room, setRoom, nights, setNights, onContinue }) {
  const selected = roomOptions.find((item) => item.name === room);
  const price = Math.round(hotel.price * selected.multiplier);

  return (
    <section className="form-card">
      <h2>Select Your Room</h2>
      <p>{hotel.name} · {hotel.location}</p>
      <label>
        Room type
        <select aria-label="Room type" value={room} onChange={(e) => setRoom(e.target.value)}>
          {roomOptions.map((item) => (
            <option key={item.name} value={item.name}>{item.name}</option>
          ))}
        </select>
      </label>
      <label>
        Number of nights
        <input
          aria-label="Number of nights"
          type="number"
          min="1"
          max="30"
          value={nights}
          onChange={(e) => setNights(Math.max(1, Math.min(30, Number(e.target.value) || 1)))}
        />
      </label>
      <h3>₹{price.toLocaleString("en-IN")} × {nights} night(s)</h3>
      <p>Room total: ₹{(price * nights).toLocaleString("en-IN")}</p>
      <button onClick={onContinue}>Continue to Booking Summary</button>
    </section>
  );
}

function BookingSummary({ hotel, room, nights, guest, setGuest, email, setEmail, onContinue }) {
  const selected = roomOptions.find((item) => item.name === room);
  const subtotal = Math.round(hotel.price * selected.multiplier) * nights;
  const tax = Math.round(subtotal * 0.12);
  const total = subtotal + tax + 200;

  return (
    <section className="form-card">
      <h2>Booking Summary</h2>
      <p>Hotel: {hotel.name}</p>
      <p>Room: {room}</p>
      <p>Number of nights: {nights}</p>
      <hr />
      <p>Room cost: ₹{subtotal.toLocaleString("en-IN")}</p>
      <p>Tax (12%): ₹{tax.toLocaleString("en-IN")}</p>
      <p>Service charge: ₹200</p>
      <h2>Total: ₹{total.toLocaleString("en-IN")}</h2>

      <label>
        Guest full name
        <input aria-label="Guest full name" autoComplete="name" value={guest} onChange={(e) => setGuest(e.target.value)} placeholder="Enter your name" />
      </label>
      <label>
        Email address
        <input aria-label="Email address" autoComplete="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Enter your email" />
      </label>
      <button disabled={!guest.trim() || !email.includes("@")} onClick={onContinue}>
        Continue to Payment
      </button>
    </section>
  );
}

function Payment({ total, onConfirm, onBack }) {
  return (
    <section className="form-card">
      <h2>Payment</h2>
      <p>Amount due: <strong>₹{total.toLocaleString("en-IN")}</strong></p>
      <p>This is a demonstration checkout. No real payment will be processed.</p>
      <div className="actions">
        <button className="secondary" onClick={onBack}>Back</button>
        <button onClick={onConfirm}>Confirm Demo Booking</button>
      </div>
    </section>
  );
}


function Footer() {
  return (
    <footer className="footer">
      <strong>StayEasy</strong>
      <p>Find your stay. Travel with comfort.</p>
      <small>© 2026 StayEasy Hotel Booking Demo</small>
    </footer>
  );
}

function Home({ onExplore }) {
  return (
    <section className="hero">
      <div className="hero-copy">
        <p className="eyebrow">YOUR NEXT GETAWAY STARTS HERE</p>
        <h1>Find a stay worth travelling for.</h1>
        <p>Discover handpicked hotels, comfortable rooms and stays for every budget.</p>
        <button onClick={onExplore}>Explore Hotels</button>
      </div>
      <img
        src="https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=1200"
        alt="Beautiful hotel swimming pool" loading="lazy" decoding="async"
      />
    </section>
  );
}

export default function App() {
  const [page, setPage] = useState("home");
  const [authToken, setAuthToken] = useState(() => sessionStorage.getItem("accessToken"));
  const [authUser, setAuthUser] = useState(() => {
    try { return JSON.parse(sessionStorage.getItem("authUser") || "null"); } catch { return null; }
  });

  function handleLogin(data) {
    setAuthToken(data.accessToken);
    setAuthUser({ username: data.username, firstName: data.firstName });
    setPage("home");
  }

  function handleLogout() {
    sessionStorage.removeItem("accessToken");
    sessionStorage.removeItem("authUser");
    setAuthToken(null);
    setAuthUser(null);
    setPage("home");
  }

  function goToPage(nextPage) {
    if (["bookings", "payment"].includes(nextPage) && !sessionStorage.getItem("accessToken")) {
      setPage("login");
      return;
    }
    setPage(nextPage);
  }
  const [search, setSearch] = useState("");
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [maxPrice, setMaxPrice] = useState(8000);
  const [rating, setRating] = useState(0);
  const [amenities, setAmenities] = useState([]);
  const [hotel, setHotel] = useState(null);
  const [room, setRoom] = useState("Deluxe");
  const [nights, setNights] = useState(1);
  const [guest, setGuest] = useState("");
  const [email, setEmail] = useState("");
  const [booking, setBooking] = useState(null);
  const [bookings, setBookings] = useState(() =>
    JSON.parse(localStorage.getItem("stayBooking") || "[]")
  );

  const filteredHotels = useMemo(
    () =>
      hotelData.filter((item) => {
        const matchesSearch = `${item.name} ${item.location}`
          .toLowerCase()
          .includes(search.toLowerCase());
        const matchesPrice = item.price <= maxPrice;
        const matchesRating = item.rating >= rating;
        const matchesAmenities = amenities.every((itemName) =>
          item.amenities.includes(itemName)
        );
        return matchesSearch && matchesPrice && matchesRating && matchesAmenities;
      }),
    [search, maxPrice, rating, amenities]
  );

  const selectedRoom = roomOptions.find((item) => item.name === room);
  const subtotal = hotel ? Math.round(hotel.price * selectedRoom.multiplier) * nights : 0;
  const total = subtotal + Math.round(subtotal * 0.12) + 200;

  function selectHotel(item) {
    setHotel(item);
    setPage("detail");
  }

  async function confirmBooking() {
    const token = sessionStorage.getItem("accessToken");
    if (!token) { setPage("login"); return; }
    const newBooking = {
      bookingId: "SE" + Date.now(),
      hotel,
      room,
      nights,
      guest,
      email,
      total,
      checkIn,
      checkOut,
      date: new Date().toLocaleDateString(),
    };
    const updated = [...bookings, newBooking];
    setBookings(updated);
    localStorage.setItem("stayBooking", JSON.stringify(updated));
    // Demo reservation request with the authentication token attached.
    try {
      const response = await fetch("https://jsonplaceholder.typicode.com/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ bookingId: newBooking.bookingId, hotel: newBooking.hotel.name, room: newBooking.room, total: newBooking.total }),
      });
      if (response.status === 401 || response.status === 403) {
        handleLogout();
        setPage("login");
        alert("Your session is unauthorized or expired. Please log in again.");
        return;
      }
    } catch (error) {
      console.warn("Demo reservation API request failed:", error);
    }
    setBooking(newBooking);
    setPage("confirmation");
  }

  function cancelBooking(id) {
    const updated = bookings.filter((item) => item.bookingId !== id);
    setBookings(updated);
    localStorage.setItem("stayBooking", JSON.stringify(updated));
  }

  return (
    <>
      <Header page={page} onNavigate={goToPage} user={authUser} onLogout={handleLogout} />
      <main className="app-main">
        {page === "login" && (
          <Suspense fallback={<Loading />}><Login onLogin={handleLogin} onBack={() => setPage("home")} /></Suspense>
        )}
        {page === "home" && <Home onExplore={() => setPage("hotels")} />}
        {page === "tools" && <CrudReduxTools />}

        {page === "hotels" && (
          <>
            <div className="page-heading">
              <p className="eyebrow">EXPLORE YOUR OPTIONS</p>
              <h1>Find your perfect stay</h1>
              <p>Search destinations and refine your stay with filters.</p>
            </div>
            <SearchBar
              search={search}
              setSearch={setSearch}
              checkIn={checkIn}
              setCheckIn={setCheckIn}
              checkOut={checkOut}
              setCheckOut={setCheckOut}
            />
            <div className="listing-layout">
              <FilterPanel
                maxPrice={maxPrice}
                setMaxPrice={setMaxPrice}
                rating={rating}
                setRating={setRating}
                amenities={amenities}
                setAmenities={setAmenities}
              />
              <HotelList hotels={filteredHotels} onSelect={selectHotel} />
            </div>
          </>
        )}

        {page === "detail" && hotel && (
          <HotelDetail
            hotel={hotel}
            onBack={() => setPage("hotels")}
            onSelectRoom={() => setPage("room")}
          />
        )}

        {page === "room" && hotel && (
          <RoomSelection
            hotel={hotel}
            room={room}
            setRoom={setRoom}
            nights={nights}
            setNights={setNights}
            onContinue={() => setPage("summary")}
          />
        )}

        {page === "summary" && hotel && (
          <BookingSummary
            hotel={hotel}
            room={room}
            nights={nights}
            guest={guest}
            setGuest={setGuest}
            email={email}
            setEmail={setEmail}
            onContinue={() => goToPage("payment")}
          />
        )}

        {page === "payment" && hotel && (
          <Payment
            total={total}
            onBack={() => setPage("summary")}
            onConfirm={confirmBooking}
          />
        )}

        {page === "confirmation" && booking && (
          <section className="confirmation">
            <div className="success-icon">✓</div>
            <p className="eyebrow">RESERVATION COMPLETE</p>
            <h1>Booking confirmed!</h1>
            <p>Your demo reservation has been saved.</p>
            <div className="receipt">
              <p>Booking ID: <strong>{booking.bookingId}</strong></p>
              <p>Hotel: <strong>{booking.hotel.name}</strong></p>
              <p>Guest: <strong>{booking.guest}</strong></p>
              <p>Room: <strong>{booking.room}</strong></p>
              <p>Total: <strong>₹{booking.total.toLocaleString("en-IN")}</strong></p>
            </div>
            <button onClick={() => setPage("bookings")}>View My Bookings</button>
            <button className="secondary" onClick={() => setPage("hotels")}>Explore More Hotels</button>
          </section>
        )}

        {page === "bookings" && (
          <section>
            <h1>My Bookings</h1>
            {bookings.length === 0 ? (
              <p className="empty">No bookings yet. Explore hotels to make a reservation.</p>
            ) : bookings.map((item) => (
              <article className="booking-row" key={item.bookingId}>
                <div>
                  <h3>{item.hotel.name}</h3>
                  <p>{item.hotel.location} · {item.room} · {item.nights} night(s)</p>
                  <p>Booking ID: {item.bookingId}</p>
                  <strong>₹{item.total.toLocaleString("en-IN")}</strong>
                </div>
                <button className="secondary" onClick={() => cancelBooking(item.bookingId)}>
                  Cancel Booking
                </button>
              </article>
            ))}
          </section>
        )}
      </main>
      <Footer />
    </>
  );
}
