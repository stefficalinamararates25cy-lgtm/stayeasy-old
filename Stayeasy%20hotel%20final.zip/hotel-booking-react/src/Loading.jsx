
function Loading() {
  return (
    <div className="panel">
      <p>Loading hotels, please wait...</p>
    </div>
  );
}

export default Loading;
