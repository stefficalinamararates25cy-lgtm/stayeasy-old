export function filterHotels(hotels, { search = "", maxPrice = Infinity, rating = 0, amenities = [] } = {}) {
  const query = search.trim().toLowerCase();
  return hotels.filter((hotel) =>
    `${hotel.name} ${hotel.location}`.toLowerCase().includes(query) &&
    hotel.price <= maxPrice && hotel.rating >= rating &&
    amenities.every((amenity) => hotel.amenities.includes(amenity))
  );
}

export function calculateBookingCost(price, roomMultiplier = 1, nights = 1, taxRate = 0.12, serviceCharge = 200) {
  const safeNights = Math.max(1, Math.min(30, Number(nights) || 1));
  const subtotal = Math.round(Number(price) * Number(roomMultiplier)) * safeNights;
  const tax = Math.round(subtotal * taxRate);
  return { subtotal, tax, serviceCharge, total: subtotal + tax + serviceCharge };
}

export function validateGuest(guest, email) {
  return Boolean(String(guest || "").trim() && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || "")));
}
