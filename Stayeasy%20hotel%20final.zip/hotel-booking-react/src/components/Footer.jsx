
function Footer() {
  return (
    <footer>
      <p>StayEasy © 2026 | Hotel Booking Application</p>
    </footer>
  );
}

export default Footer;
