
import { Link } from "react-router-dom";

function HotelCard({ hotel, onSelect }) {
  return (
    <article className="hotel-card">
      <h3>{hotel.name}</h3>
      <p>Location: {hotel.location}</p>
      <p>Rating: {"★".repeat(hotel.stars)}</p>
      <p>Amenities: {hotel.amenities.join(", ")}</p>
      <h3>₹{hotel.price} / night</h3>
      <Link className="button secondary" to={`/hotel/${hotel.id}`}>
        Details
      </Link>{" "}
      <button onClick={() => onSelect(hotel)}>Select Hotel</button>
    </article>
  );
}

export default HotelCard;
