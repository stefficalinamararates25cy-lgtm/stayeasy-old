
import { useLocation, useNavigate, useParams } from "react-router-dom";

const hotels = [
  { id: 1, name: "Grand Palace Hotel", location: "Chennai", price: 5000, rating: 5 },
  { id: 2, name: "Green Valley Resort", location: "Ooty", price: 3500, rating: 4 },
  { id: 3, name: "City Comfort Inn", location: "Coimbatore", price: 1800, rating: 3 },
  { id: 4, name: "Marina Beach Hotel", location: "Chennai", price: 3200, rating: 4 },
  { id: 5, name: "Mountain View Stay", location: "Kodaikanal", price: 6000, rating: 5 },
];

export default function HotelDetails() {
  const { id } = useParams();
  const { state } = useLocation();
  const navigate = useNavigate();

  const hotel =
    state?.hotel || hotels.find((item) => item.id === Number(id));

  if (!hotel) {
    return (
      <div style={{ padding: 30 }}>
        <h2>Hotel not found</h2>
        <button onClick={() => navigate("/hotels")}>View Hotels</button>
      </div>
    );
  }

  return (
    <div style={{ padding: 30 }}>
      <h1>{hotel.name}</h1>
      <h3>Location: {hotel.location}</h3>
      <h2>₹{hotel.price} / night</h2>
      <p>Rating: {hotel.rating} stars</p>

      <button
        onClick={() =>
          navigate("/booking/room", { state: { hotel } })
        }
      >
        Select Room
      </button>

      <button onClick={() => navigate("/hotels")}>
        Back to Hotels
      </button>
    </div>
  );
}
