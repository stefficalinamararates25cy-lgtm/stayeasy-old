
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const hotels = [
  { id: 1, name: "Grand Palace Hotel", location: "Chennai", price: 5000 },
  { id: 2, name: "Green Valley Resort", location: "Ooty", price: 3500 },
  { id: 3, name: "City Comfort Inn", location: "Coimbatore", price: 1800 },
  { id: 4, name: "Marina Beach Hotel", location: "Chennai", price: 3200 },
  { id: 5, name: "Mountain View Stay", location: "Kodaikanal", price: 6000 },
];

export default function HotelSearch() {
  const [search, setSearch] = useState("");
  const navigate = useNavigate();

  const filteredHotels = hotels.filter((hotel) =>
    (hotel.name + " " + hotel.location)
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <div style={{ padding: "25px" }}>
      <h1>Hotel Collection</h1>

      <input
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search hotel or location..."
        style={{ padding: "12px", width: "280px" }}
      />

      {filteredHotels.map((hotel) => (
        <div
          key={hotel.id}
          style={{
            border: "1px solid #ccc",
            padding: "16px",
            margin: "15px 0",
            borderRadius: "8px",
          }}
        >
          <h2>{hotel.name}</h2>
          <p>Location: {hotel.location}</p>
          <p>Price: ₹{hotel.price} per night</p>

          <button
            onClick={() =>
              navigate(`/hotel/${hotel.id}`, { state: { hotel } })
            }
          >
            View Hotel
          </button>
        </div>
      ))}

      {filteredHotels.length === 0 && <p>No hotels found.</p>}
    </div>
  );
}
