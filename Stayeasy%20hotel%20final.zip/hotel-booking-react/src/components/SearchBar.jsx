
function SearchBar({
  location,
  setLocation,
  checkIn,
  checkOut,
  setDates,
  inputRef
}) {
  return (
    <section className="panel search-grid">
      <label>
        Destination
        <input
          ref={inputRef}
          value={location}
          placeholder="Enter city"
          onChange={(e) => setLocation(e.target.value)}
        />
      </label>

      <label>
        Check-in
        <input
          type="date"
          value={checkIn}
          onChange={(e) => setDates(e.target.value, checkOut)}
        />
      </label>

      <label>
        Check-out
        <input
          type="date"
          min={checkIn || undefined}
          value={checkOut}
          onChange={(e) => setDates(checkIn, e.target.value)}
        />
      </label>
    </section>
  );
}

export default SearchBar;
