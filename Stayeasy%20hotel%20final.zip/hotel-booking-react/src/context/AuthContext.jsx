
import {
  createContext,
  useContext,
  useState,
  useCallback
} from "react";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("stayUser")) || null;
    } catch {
      return null;
    }
  });

  const login = useCallback((email) => {
    const account = { email };
    setUser(account);
    localStorage.setItem("stayUser", JSON.stringify(account));
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem("stayUser");
  }, []);

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}

export default AuthContext;
