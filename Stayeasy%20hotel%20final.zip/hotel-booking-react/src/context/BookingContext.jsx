
import { createContext, useContext, useState } from "react";

const BookingContext = createContext(null);

export function BookingProvider({ children }) {
  const [booking, setBooking] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("stayBooking")) || {};
    } catch {
      return {};
    }
  });

  function updateBooking(details) {
    setBooking((previous) => {
      const updated = { ...previous, ...details };
      localStorage.setItem("stayBooking", JSON.stringify(updated));
      return updated;
    });
  }

  function clearBooking() {
    localStorage.removeItem("stayBooking");
    setBooking({});
  }

  return (
    <BookingContext.Provider
      value={{ booking, updateBooking, clearBooking }}
    >
      {children}
    </BookingContext.Provider>
  );
}

export function useBooking() {
  const context = useContext(BookingContext);

  if (!context) {
    throw new Error("useBooking must be used inside BookingProvider");
  }

  return context;
}
