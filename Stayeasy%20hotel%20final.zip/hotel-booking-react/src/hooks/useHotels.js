
import { useEffect, useMemo, useState } from "react";

const hotelData = [
  {
    id: 101,
    name: "Grand Palace Hotel",
    location: "Chennai",
    stars: 5,
    price: 5000,
    amenities: ["Wi-Fi", "Pool", "Restaurant"],
    rooms: [
      { name: "Standard", price: 2500 },
      { name: "Deluxe", price: 4000 },
      { name: "Suite", price: 6500 }
    ]
  },
  {
    id: 102,
    name: "Green Valley Resort",
    location: "Ooty",
    stars: 4,
    price: 3500,
    amenities: ["Wi-Fi", "Garden", "Restaurant"],
    rooms: [
      { name: "Standard", price: 2000 },
      { name: "Deluxe", price: 3500 }
    ]
  },
  {
    id: 103,
    name: "City Comfort Inn",
    location: "Coimbatore",
    stars: 3,
    price: 1800,
    amenities: ["Wi-Fi", "Parking"],
    rooms: [
      { name: "Standard", price: 1500 },
      { name: "Family", price: 2800 }
    ]
  },
  {
    id: 104,
    name: "Marina Beach Hotel",
    location: "Chennai",
    stars: 4,
    price: 3200,
    amenities: ["Wi-Fi", "Pool", "Restaurant"],
    rooms: [
      { name: "Sea View", price: 4000 },
      { name: "Deluxe", price: 3200 }
    ]
  }
];

export default function useHotels() {
  const [hotels, setHotels] = useState([]);
  const [location, setLocation] = useState("");
  const [maxPrice, setMaxPrice] = useState(10000);
  const [stars, setStars] = useState(0);
  const [wifi, setWifi] = useState(false);
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");

  useEffect(() => {
    setHotels(hotelData);
  }, []);

  const filteredHotels = useMemo(() => {
    return hotels.filter((hotel) => {
      const matchesLocation =
        (hotel.name + " " + hotel.location)
          .toLowerCase()
          .includes(location.toLowerCase());

      const matchesPrice = hotel.price <= maxPrice;
      const matchesStars = hotel.stars >= stars;
      const matchesWifi =
        !wifi || hotel.amenities.includes("Wi-Fi");

      return (
        matchesLocation &&
        matchesPrice &&
        matchesStars &&
        matchesWifi
      );
    });
  }, [hotels, location, maxPrice, stars, wifi]);

  const updateDates = (start, end) => {
    setCheckIn(start);
    setCheckOut(end);
  };

  return {
    hotels: filteredHotels,
    location,
    setLocation,
    maxPrice,
    setMaxPrice,
    stars,
    setStars,
    wifi,
    setWifi,
    checkIn,
    checkOut,
    updateDates
  };
}
