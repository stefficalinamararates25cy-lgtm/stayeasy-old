
import { Link, Navigate } from "react-router-dom";
import { useBooking } from "../context/BookingContext";

function Confirmation() {
  const booking = useBooking();
  const confirmed = booking.confirmed;

  if (!confirmed) {
    return <Navigate to="/hotels" replace />;
  }

  return (
    <section className="panel">
      <h2>Booking Confirmed!</h2>
      <p>Your hotel booking was successful.</p>

      <h3>Booking Details</h3>
      <p>
        <strong>Guest Name:</strong>{" "}
        {confirmed.name || booking.customer?.name}
      </p>
      <p>
        <strong>Hotel:</strong>{" "}
        {confirmed.hotel?.name || booking.hotel?.name}
      </p>
      <p>
        <strong>Room:</strong>{" "}
        {confirmed.room?.name || booking.room?.name}
      </p>
      <p>
        <strong>Check-in:</strong> {booking.checkIn}
      </p>
      <p>
        <strong>Check-out:</strong> {booking.checkOut}
      </p>
      <p>
        <strong>Total Amount:</strong> ₹
        {confirmed.total ?? booking.total}
      </p>

      <Link to="/bookings">
        <button type="button">View My Bookings</button>
      </Link>

      <Link to="/hotels">
        <button type="button">Back to Hotels</button>
      </Link>
    </section>
  );
}

export default Confirmation;
