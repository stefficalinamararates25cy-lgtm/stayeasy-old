import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setHotel, setRoom, setGuests, setCustomer, confirmBooking, clearBooking } from "../redux/bookingSlice.js";

const API = "https://jsonplaceholder.typicode.com/posts";

export default function CrudReduxTools() {
  const dispatch = useDispatch();
  const reduxBooking = useSelector((state) => state.booking);
  const [items, setItems] = useState([]);
  const [title, setTitle] = useState("StayEasy demo reservation");
  const [loading, setLoading] = useState(false);
  const [apiMessage, setApiMessage] = useState("No API request yet. Click Load (GET) to start.");
  const [storageMessage, setStorageMessage] = useState("Storage check not run yet.");

  useEffect(() => {
    console.info("[Redux] Current booking state:", reduxBooking);
  }, [reduxBooking]);

  async function request(label, url, options) {
    setLoading(true);
    console.info(`[REST API] ${label}`, { url, method: options?.method || "GET" });
    try {
      const response = await fetch(url, options);
      const data = response.status === 204 ? null : await response.json();
      console.info(`[REST API] ${label} response`, { status: response.status, data });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      setApiMessage(`${label}: HTTP ${response.status} — success. See DevTools → Network → Fetch/XHR.`);
      return data;
    } catch (error) {
      console.error(`[REST API] ${label} failed`, error);
      setApiMessage(`${label} failed: ${error.message}. Check internet and Network tab.`);
      return null;
    } finally {
      setLoading(false);
    }
  }

  async function loadItems() {
    const data = await request("GET /posts?_limit=5", `${API}?_limit=5`);
    if (data) setItems(data);
  }

  async function createItem() {
    const data = await request("POST /posts", API, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, body: "Created from StayEasy CRUD testing", userId: 1 }),
    });
    if (data) setItems((previous) => [data, ...previous].slice(0, 6));
  }

  async function updateItem(item) {
    const data = await request(`PUT /posts/${item.id}`, `${API}/${item.id}`, {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...item, title: `${item.title} (updated)`, body: "Updated from StayEasy CRUD testing" }),
    });
    if (data) setItems((previous) => previous.map((entry) => entry.id === item.id ? { ...entry, ...data } : entry));
  }

  async function deleteItem(item) {
    const data = await request(`DELETE /posts/${item.id}`, `${API}/${item.id}`, { method: "DELETE" });
    if (data !== null) setItems((previous) => previous.filter((entry) => entry.id !== item.id));
  }

  function testStorage() {
    try {
      localStorage.setItem("stayEasyCrudTest", JSON.stringify({ checkedAt: new Date().toISOString(), source: "CrudReduxTools" }));
      sessionStorage.setItem("stayEasySessionTest", JSON.stringify({ checkedAt: new Date().toISOString(), source: "CrudReduxTools" }));
      const local = localStorage.getItem("stayEasyCrudTest");
      const session = sessionStorage.getItem("stayEasySessionTest");
      console.info("[localStorage] stayEasyCrudTest:", local);
      console.info("[sessionStorage] stayEasySessionTest:", session);
      setStorageMessage("PASS: localStorage and sessionStorage write/read succeeded. Check DevTools → Application → Storage.");
    } catch (error) {
      console.error("[Storage test] failed", error);
      setStorageMessage(`Storage test failed: ${error.message}`);
    }
  }

  function testRedux() {
    dispatch(setHotel({ id: 900, name: "Redux Demo Hotel", location: "Coimbatore", price: 2500 }));
    dispatch(setRoom({ id: 1, type: "Deluxe", price: 2500 }));
    dispatch(setGuests(2));
    dispatch(setCustomer({ name: "Demo Guest", phone: "9000000000" }));
    dispatch(confirmBooking());
    console.info("[Redux] Demo actions dispatched. Inspect Redux DevTools if installed, and Console for Booking Action logs.");
  }

  return (
    <main className="container panel" style={{ maxWidth: 1000, margin: "2rem auto", padding: "1.5rem" }}>
      <p className="eyebrow">DEVELOPER TEST AREA</p>
      <h1>REST API, CRUD & Redux Testing</h1>
      <p>Use these controls to generate real browser requests and inspect Console, Network, Application storage, and Redux state.</p>

      <section style={{ margin: "1.5rem 0", padding: "1rem", border: "1px solid #ddd", borderRadius: 12 }}>
        <h2>REST API CRUD (JSONPlaceholder demo)</h2>
        <label>New post title <input value={title} onChange={(event) => setTitle(event.target.value)} /></label>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", margin: "1rem 0" }}>
          <button onClick={loadItems} disabled={loading}>Load (GET)</button>
          <button onClick={createItem} disabled={loading}>Create (POST)</button>
        </div>
        <p role="status">{loading ? "Request in progress…" : apiMessage}</p>
        {items.map((item) => <article key={item.id} style={{ borderTop: "1px solid #ddd", padding: "0.8rem 0" }}>
          <strong>#{item.id} {item.title}</strong>
          <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
            <button className="secondary" onClick={() => updateItem(item)} disabled={loading}>Update (PUT)</button>
            <button className="secondary" onClick={() => deleteItem(item)} disabled={loading}>Delete</button>
          </div>
        </article>)}
        <small>Note: JSONPlaceholder simulates POST/PUT/DELETE responses; changes are not permanently saved on its server.</small>
      </section>

      <section style={{ margin: "1.5rem 0", padding: "1rem", border: "1px solid #ddd", borderRadius: 12 }}>
        <h2>Redux state test</h2>
        <button onClick={testRedux}>Run Redux Actions</button>{" "}
        <button className="secondary" onClick={() => dispatch(clearBooking())}>Clear Redux Booking</button>
        <p>Selected hotel: {reduxBooking.selectedHotel?.name || "None"}</p>
        <p>Room: {reduxBooking.selectedRoom?.type || "None"} · Guests: {reduxBooking.guests}</p>
        <p>Customer: {reduxBooking.customerName || "None"}</p>
        <p>Redux bookings in state: {reduxBooking.bookings?.length || 0}</p>
        <small>Redux middleware prints each action in Console and persists booking state in localStorage under <code>hotelBooking</code>.</small>
      </section>

      <section style={{ margin: "1.5rem 0", padding: "1rem", border: "1px solid #ddd", borderRadius: 12 }}>
        <h2>Browser storage test</h2>
        <button onClick={testStorage}>Test localStorage + sessionStorage</button>
        <p role="status">{storageMessage}</p>
        <small>Open DevTools → Application → Local Storage / Session Storage to inspect the test keys.</small>
      </section>

      <section style={{ background: "#f4f6f8", color: "#222", padding: "1rem", borderRadius: 12 }}>
        <h2>Where to verify</h2>
        <ul>
          <li><strong>Console:</strong> [REST API], [Redux], and [Storage test] messages.</li>
          <li><strong>Network → Fetch/XHR:</strong> GET, POST, PUT, DELETE requests to jsonplaceholder.typicode.com.</li>
          <li><strong>Application → Local Storage:</strong> hotelBooking and stayEasyCrudTest.</li>
          <li><strong>Application → Session Storage:</strong> stayEasySessionTest and accessToken after login.</li>
        </ul>
      </section>
    </main>
  );
}
