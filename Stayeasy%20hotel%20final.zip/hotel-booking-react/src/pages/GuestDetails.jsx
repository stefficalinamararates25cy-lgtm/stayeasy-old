
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useBooking } from "../context/BookingContext";

function GuestDetails() {
  const booking = useBooking();
  const navigate = useNavigate();

  const [name, setName] = useState(booking.customer?.name || "");
  const [email, setEmail] = useState(booking.customer?.email || "");
  const [phone, setPhone] = useState(booking.customer?.phone || "");

  function handleSubmit(e) {
    e.preventDefault();

    if (!booking.hotel) {
      alert("Please select a hotel.");
      return;
    }

    if (!booking.room) {
      alert("Please select a room.");
      return;
    }

    if (!booking.checkIn || !booking.checkOut || booking.nights < 1) {
      alert("Please select valid check-in and check-out dates.");
      return;
    }

    booking.setCustomer({ name, email, phone });
    navigate("/booking/summary");
  }

  if (!booking.hotel) {
    return (
      <section className="panel">
        <h2>Select a hotel first</h2>
        <Link to="/hotels">Browse Hotels</Link>
      </section>
    );
  }

  return (
    <form className="panel form-grid" onSubmit={handleSubmit}>
      <h2>Guest Details</h2>

      <label>Full Name</label>
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
        placeholder="Enter your name"
      />

      <label>Email</label>
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
        placeholder="Enter your email"
      />

      <label>Phone Number</label>
      <input
        type="tel"
        value={phone}
        onChange={(e) => setPhone(e.target.value)}
        pattern="[0-9]{10}"
        maxLength={10}
        required
        placeholder="10-digit phone number"
      />

      <button type="submit">Continue to Summary</button>
    </form>
  );
}

export default GuestDetails;
