
import { useEffect, useRef } from "react";
import useHotels from "../hooks/useHotels";
import { useBooking } from "../context/BookingContext";
import SearchBar from "../components/SearchBar";
import FilterPanel from "../components/FilterPanel";
import HotelList from "../components/HotelList";

function Hotels() {
  const {
    hotels, location, setLocation,
    maxPrice, setMaxPrice, stars, setStars,
    wifi, setWifi, checkIn, checkOut, updateDates
  } = useHotels();

  const { selectHotel, updateDates: saveDates } = useBooking();
  const inputRef = useRef(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    saveDates(checkIn, checkOut);
  }, [checkIn, checkOut, saveDates]);

  return (
    <main className="container">
      <h1>Find Your Hotel</h1>

      <SearchBar
        location={location}
        setLocation={setLocation}
        checkIn={checkIn}
        checkOut={checkOut}
        setDates={updateDates}
        inputRef={inputRef}
      />

      <FilterPanel
        maxPrice={maxPrice}
        setMaxPrice={setMaxPrice}
        stars={stars}
        setStars={setStars}
        wifi={wifi}
        setWifi={setWifi}
      />

      <h2>Available Hotels</h2>

      <HotelList
        hotels={hotels}
        onSelect={selectHotel}
      />
    </main>
  );
}

export default Hotels;
