import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
  base: process.env.GITHUB_PAGES === "true" ? "/hotel-booking-react/" : "/",
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      includeAssets: ["favicon.svg"],
      manifest: {
        name: "StayEasy Hotel Booking",
        short_name: "StayEasy",
        description: "Search hotels and manage demo reservations.",
        theme_color: "#174ea6",
        background_color: "#ffffff",
        display: "standalone",
        start_url: ".",
        icons: []
      }
    })
  ],
  test: { environment: "jsdom", globals: true, setupFiles: "./src/testSetup.js" }
});
